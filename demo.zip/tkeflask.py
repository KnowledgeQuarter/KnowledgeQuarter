# -*- coding: utf-8 -*-
"""
Created on Fri Dec 11 17:09:11 2020

@author: Kirsch
"""

from flask import Flask, render_template, g, redirect, url_for, request, send_file



#Create the web application
application = Flask(__name__)


#Initialize the web app first page
@application.route("/")
def index():
    return render_template("mvp_backend.html")


if __name__ == "__main__":
    # execute only if run as a script
    application.run()
